import { Spaceship } from './spaceship';
import { Cargo } from './cargo';
import { Planet } from './planet';

export class Mission {
  public readonly failureReasons: string[] = [];
  constructor(
    public readonly spaceship: Spaceship,
    public readonly cargo: Cargo,
    public readonly destination: Planet
  ) {}

  private isSucceded(): boolean {
    return this.failureReasons.length === 0;
  }

  private checkFailures(): void{

    if (!this.spaceship.canCarry(this.cargo)) {
      this.failureReasons.push(`A carga '${this.cargo.name}' excede a capacidade da nave ${this.spaceship.name} (${this.cargo.weight.toFixed(2)} > ${this.spaceship.cargoCapacity})`);
    }

    if (!this.spaceship.hasFuelFor(this.destination.distanceFromEarth)) {
      this.failureReasons.push(`A nave não tem combustivél suficiente para chegar ao planeta ${this.destination.name} (${this.destination.distanceFromEarth * this.spaceship.fuelConsumptionPerUnit} > ${this.spaceship.fuelTankCapacity})`);
    }

    if (!this.destination.isCompatibleWithCargo(this.cargo)) {
      this.failureReasons.push(`O planeta ${this.destination.name} não aceita a carga ${this.cargo.name}`);
    }

    if (this.destination.requiresShield && !this.spaceship.hasShield) {
      this.failureReasons.push(`A nave ${this.spaceship.name} não possui um escudo para levar a carga ${this.cargo.name} ao planeta ${this.destination.name}`);
    }
  }

  execute(): string {
    this.checkFailures();
    if (this.isSucceded()) {
      return `:) Missão bem-sucedida: ${this.spaceship.name} entregou '${this.cargo.name}' em ${this.destination.name}`;
    } else {
      const failureLog = [
        `:( Missão falhou: ${this.spaceship.name} não conseguiu entregar '${this.cargo.name}' em ${this.destination.name}.`,
        'Motivos:'
      ].concat(this.failureReasons.map(r => `  - ${r}`)).join('\n');
      return failureLog;
    }
  }
}
