import { Cargo, CargoType } from "./cargo";

export const planetNames = ["Zephyria", "Xandros", "Cryon", "Virelia", "Orionis", "Ecliptica", "Aether", "Draconis"];

export abstract class Planet {
  constructor(
    public readonly name: string,
    public readonly distanceFromEarth: number,
    public readonly acceptedCargos: CargoType[],
    public readonly requiresShield: boolean
  ) {}

  isCompatibleWithCargo(cargo: Cargo): boolean {
    return this.acceptedCargos.includes(cargo.getType());
  }
}

export class RockyPlanet extends Planet {
  static readonly distance = 650;
  static readonly acceptedCargos = [CargoType.supplyPackage, CargoType.miningTool, CargoType.oxygenTank];
  static readonly requiresShield = false;

  constructor(name: string) {
    super(name, RockyPlanet.distance, RockyPlanet.acceptedCargos, RockyPlanet.requiresShield);
  }
}

export class CorrosivePlanet extends Planet {
  static readonly distance = 700;
  static readonly acceptedCargos = [CargoType.shieldedCapsule, CargoType.oxygenTank];
  static readonly requiresShield = true;

  constructor(name: string) {
    super(name, CorrosivePlanet.distance, CorrosivePlanet.acceptedCargos, CorrosivePlanet.requiresShield);
  }
}

export class HeatPlanet extends Planet {
  static readonly distance = 900;
  static readonly acceptedCargos = [CargoType.shieldedCapsule, CargoType.miningTool];
  static readonly requiresShield = true;
  
  constructor(name: string){
    super(name, HeatPlanet.distance, HeatPlanet.acceptedCargos, HeatPlanet.requiresShield);
  }
}

export class IcyPlanet extends Planet {
  static readonly distance = 800;
  static readonly acceptedCargos = [CargoType.shieldedCapsule, CargoType.miningTool, CargoType.biologicalSample];
  static readonly requiresShield = false;
  
  constructor(name: string){
    super(name, IcyPlanet.distance, IcyPlanet.acceptedCargos, IcyPlanet.requiresShield);
  }
}

export class GasousPlanet extends Planet {
  static readonly distance = 1000;
  static readonly acceptedCargos = [CargoType.shieldedCapsule, CargoType.oxygenTank, CargoType.supplyPackage];
  static readonly requiresShield = false;
  
  constructor(name: string){
    super(name, GasousPlanet.distance, GasousPlanet.acceptedCargos, GasousPlanet.requiresShield);
  }
}