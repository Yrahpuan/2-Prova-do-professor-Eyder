import { Mission } from './mission';

export class MissionControl {
  private missions: Mission[] = [];

  addMission(mission: Mission): void {
    this.missions.push(mission);
  }

  executeAll(): void {
    this.missions.forEach(m => console.log(m.execute()));
  }

  showSummary(): void {
    const usedSpaceships: string[] = [];
    const usedCargos: string[] = [];
    const usedPlanets: string[] = [];
    let concludedMissions = 0;
    let failedMissions = 0;

    this.missions.forEach(mission => {
      const usedSpaceshipIndex = usedSpaceships.indexOf(mission.spaceship.name);
      if(usedSpaceshipIndex === -1){
        usedSpaceships.push(mission.spaceship.name);
      }

      const usedCargoIndex = usedCargos.indexOf(mission.cargo.name);
      if(usedCargoIndex === -1){
        usedCargos.push(mission.cargo.name);
      }
      const usedPlanetIndex = usedPlanets.indexOf(mission.destination.name);
      if(usedPlanetIndex === -1){
        usedPlanets.push(mission.destination.name);
      }
      
      if(mission.failureReasons.length === 0){
        concludedMissions++;
      }else{
        failedMissions++;
      }
    });

    console.log("\n===== Sumário das Missões =====");
    console.log(`Missões realizadas com sucesso: ${concludedMissions}`);
    console.log(`Missões que falharam: ${failedMissions}`);
    console.log("Naves utilizadas:");
    usedSpaceships.forEach(name => console.log("- " + name));
    console.log("Cargas transportadas:");
    usedCargos.forEach(name => console.log("- " + name));
    console.log("Planetas visitados:");
    usedPlanets.forEach(name => console.log("- " + name));
  }
}