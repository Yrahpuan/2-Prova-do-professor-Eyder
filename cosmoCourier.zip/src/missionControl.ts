import { Mission } from './mission';

export class MissionControl {
  private missions: Mission[] = [];

  addMission(mission: Mission): void {
    this.missions.push(mission);
  }

  executeAll(): void {
    this.missions.forEach(m => console.log(m.execute()));
  }

  showSummary(): void {
    const usedSpaceships: string[] = [];
    const usedCargos: string[] = [];
    const usedPlanets: string[] = [];
    let concludedMissons = 0;
    let failedMissions = 0;
    let cargoCount = 1;
    let planetCount = 1;

    this.missions.forEach(mission => {
      const usedSpaceshipIndex = usedSpaceships.indexOf(mission.spaceship.name)
      if(usedSpaceshipIndex === -1){
        usedSpaceships.push(mission.spaceship.name);
      }

      const usedCargoIndex = usedCargos.indexOf(mission.cargo.name)
      if(usedCargoIndex === -1){
        usedCargos.push(mission.cargo.name);
      }else{
        cargoCount++;
        usedCargos[usedCargoIndex] = usedCargos[usedCargoIndex].concat(` (${cargoCount} vezes)`);
      }

      const usedPlanetIndex = usedPlanets.indexOf(mission.destination.name)
      if(usedPlanetIndex === -1){
        usedPlanets.push(mission.destination.name);
      }else{
        planetCount++;
        usedPlanets[usedPlanetIndex] = usedPlanets[usedPlanetIndex].concat(` (${planetCount} vezes)`);
      }
      
      if(mission.failureReasons.length === 0){
        concludedMissons++;
      }else{
        failedMissions++;
      }
    });

    console.log("\n===== Sumário das Missões =====");
    console.log(`Missões realizadas com sucesso: ${concludedMissons}`);
    console.log(`Missões que falharam: ${failedMissions}`);
    console.log("Naves utilizadas:");
    usedSpaceships.forEach(name => console.log("- " + name));
    console.log("Cargas transportadas:");
    usedCargos.forEach(name => console.log("- " + name));
    console.log("Planetas visitados:");
    usedPlanets.forEach(name => console.log("- " + name));
  }
}