import { Cargo } from "./cargo";

export const spaceshipNames = ["Nova", "Andromeda", "Pioneer", "Voyager", "Atlas", "Celestis", "Starlance", "Nebula"];

export abstract class Spaceship {
  constructor(
    public readonly name: string,
    public readonly hasShield: boolean,
    public readonly cargoCapacity: number,
    public readonly fuelConsumptionPerUnit: number,
    public readonly fuelTankCapacity: number,
  ) {}

  canCarry(cargo: Cargo): boolean {
    return cargo.weight <= this.cargoCapacity;
  }

  hasFuelFor(distance: number): boolean {
    const fuelRequired = distance * this.fuelConsumptionPerUnit;
    return fuelRequired <= this.fuelTankCapacity;
  }
}

export class HeavyFreighter extends Spaceship {
  static readonly hasShield = false;
  static readonly cargo_capacity = 2000;
  static readonly fuel_consuption = 5;
  static readonly fuel_tank_capacity = 5000;

  constructor(name: string) {
    super(name,
      HeavyFreighter.hasShield,
      HeavyFreighter.cargo_capacity,
      HeavyFreighter.fuel_consuption,
      HeavyFreighter.fuel_tank_capacity
    );
  }
}

export class FastTransporter extends Spaceship {
  static readonly hasShield = true;
  static readonly cargo_capacity = 1000;
  static readonly fuel_consuption = 0.5;
  static readonly fuel_tank_capacity = 800;

  constructor(name: string) {
    super(name,
      FastTransporter.hasShield,
      FastTransporter.cargo_capacity,
      FastTransporter.fuel_consuption,
      FastTransporter.fuel_tank_capacity
    );
  }
}

export class ExplorationCruiser extends Spaceship {
  static readonly hasShield = true;
  static readonly cargo_capacity = 500;
  static readonly fuel_consuption = 1;
  static readonly fuel_tank_capacity = 1500;

  constructor(name: string) {
    super(name,
      ExplorationCruiser.hasShield,
      ExplorationCruiser.cargo_capacity,
      ExplorationCruiser.fuel_consuption,
      ExplorationCruiser.fuel_tank_capacity
    );
  }
}

export class CompactShuttle extends Spaceship {
  static readonly hasShield = false;
  static readonly cargo_capacity = 300;
  static readonly fuel_consuption = 0.75;
  static readonly fuel_tank_capacity = 1000;

  constructor(name: string) {
    super(name,
      CompactShuttle.hasShield,
      CompactShuttle.cargo_capacity,
      CompactShuttle.fuel_consuption,
      CompactShuttle.fuel_tank_capacity
    );
  }
}

export class BioTransporter extends Spaceship {
  static readonly hasShield = true;
  static readonly cargo_capacity = 700;
  static readonly fuel_consuption = 2;
  static readonly fuel_tank_capacity = 1000;

  constructor(name: string) {
    super(name,
      BioTransporter.hasShield,
      BioTransporter.cargo_capacity,
      BioTransporter.fuel_consuption,
      BioTransporter.fuel_tank_capacity
    );
  }
}
