import {Planet, RockyPlanet, CorrosivePlanet, HeatPlanet, planetNames, IcyPlanet, GasousPlanet} from "./planet";
import {Cargo, SupplyPackage, ShieldedCapsule, BiologicalSample, MiningTools, OxygenTank} from "./cargo";
import { Spaceship, HeavyFreighter, FastTransporter, ExplorationCruiser, CompactShuttle, BioTransporter, spaceshipNames } from "./spaceship";

export function getRandomItem<T>(items: T[]): T {
  return items[Math.floor(Math.random() * items.length)];
}

export function generateRandomNameWithId(nameList: string[]): string {
  return getRandomItem(nameList) + "-" + Math.floor(Math.random() * 1000);
}

export function verifyStringRepetition(stringVetor: string[], repetitionString: string): number{
    const itensIndex = stringVetor.indexOf(repetitionString);
    if(itensIndex === -1){
      return -1;
    }

    return itensIndex;
  }

export function generateRandomPlanets(count: number = 3): Planet[] {
  const planetConstructors = [
    RockyPlanet,
    CorrosivePlanet,
    HeatPlanet,
    IcyPlanet,
    GasousPlanet
  ];
  const planets: Planet[] = [];
  for(let i = 0; i < count; i++){
    const chosenPlanet = getRandomItem(planetConstructors);
    const chosenPlanetIndex = planetConstructors.indexOf(chosenPlanet);
    planetConstructors.splice(chosenPlanetIndex, 1);
    planets.push(new chosenPlanet(generateRandomNameWithId(planetNames)));
  }

  return planets;
}

export function generateRandomCargos(count: number = 3): Cargo[] {
  const cargoConstructors = [
    SupplyPackage,
    ShieldedCapsule,
    BiologicalSample,
    OxygenTank,
    MiningTools
  ];
  const cargos: Cargo[] = [];
  for(let i = 0; i < count; i++){
    const chosenCargo = getRandomItem(cargoConstructors);
    const chosenCargoIndex = cargoConstructors.indexOf(chosenCargo);
    cargoConstructors.splice(chosenCargoIndex, 1);
    cargos.push(new chosenCargo());
  }

  return cargos;
}

export function generateRandomSpaceships(count: number = 3): Spaceship[] {
  const spaceshipConstructors = [
    HeavyFreighter,
    FastTransporter,
    ExplorationCruiser,
    CompactShuttle,
    BioTransporter
  ];
  const spaceships: Spaceship[] = [];
  for(let i = 0; i < count; i++){
    const chosenSpaceship = getRandomItem(spaceshipConstructors);
    const chosenSpaceshipIndex = spaceshipConstructors.indexOf(chosenSpaceship);
    spaceshipConstructors.splice(chosenSpaceshipIndex, 1);
    spaceships.push(new chosenSpaceship(generateRandomNameWithId(spaceshipNames)));
  }
  return spaceships;
}