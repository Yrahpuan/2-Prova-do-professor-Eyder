export enum CargoType {
  shieldedCapsule,
  biologicalSample,
  oxygenTank,
  supplyPackage,
  miningTool
}

export abstract class Cargo {
  constructor(
    public readonly name: string,
    public readonly weight: number,
    public readonly type: CargoType
  ) {}

  getType(): CargoType {
    return this.type;
  }

}

export class SupplyPackage extends Cargo {
  static readonly defaultWeight = 50;
  static readonly type = CargoType.supplyPackage

  constructor() {
    super("Pacote de Suprimentos", SupplyPackage.defaultWeight, SupplyPackage.type);
  }
}

export class ShieldedCapsule extends Cargo {
  static readonly defaultWeight = 100;
  static readonly type = CargoType.shieldedCapsule;

  constructor() {
    super("Cápsula Blindada", ShieldedCapsule.defaultWeight, ShieldedCapsule.type);
  }
}

export class BiologicalSample extends Cargo {
  static readonly defaultWeight = 10;
  static readonly type = CargoType.biologicalSample;

  constructor() {
    super("Amostra Biológica", BiologicalSample.defaultWeight, BiologicalSample.type);
  }
}

export class OxygenTank extends Cargo {
  static readonly defaultWeight = 100;
  static readonly type = CargoType.oxygenTank;

  constructor() {
    super("Tanque de oxigênio", OxygenTank.defaultWeight, OxygenTank.type);
  }
}

export class MiningTools extends Cargo {
  static readonly defaultWeight = 30;
  static readonly type = CargoType.oxygenTank;

  constructor() {
    super("Ferramentas de mineração", MiningTools.defaultWeight, MiningTools.type);
  }
}