import { Mission } from './mission';
import { MissionControl } from './missionControl';
import { generateRandomSpaceships, generateRandomPlanets, generateRandomCargos, getRandomItem } from './utils';

const missionControl = new MissionControl();
const spaceships = generateRandomSpaceships(2);
const cargo = generateRandomCargos(3);
const planet = generateRandomPlanets(4);

spaceships.forEach(spaceship => {
  for (let i = 0; i < 2; i++) {
    const mission = new Mission(spaceship,
      getRandomItem(cargo),
      getRandomItem(planet)
    );
    missionControl.addMission(mission);
  }
});

missionControl.executeAll();
missionControl.showSummary();